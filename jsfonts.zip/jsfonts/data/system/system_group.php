<?php exit;?>{
    "1": {
        "groupID": 1,
        "name": "public",
        "parentID": "",
        "children": "",
        "config": {
            "sizeMax": 0,
            "sizeUse": 0
        },
        "path": "public",
        "createTime": 1762886061
    }
}